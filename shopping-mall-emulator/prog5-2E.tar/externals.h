/* externals.h

//THIS CODE IS WRITTEN BY BOB KINICKI: HE HAS FULL CREDIT

The list of the two globals that are in main but
external to all other components and the global defs.      */

#include "globals.h"

extern int type  [MAX+1][MAX+1][2];
extern int step  [MAX+1][MAX+1][2];



